import dearpygui.dearpygui as dpg
import time
import math
import ctypes
import sys
import os

def resource_path(relative_path):
    """Devuelve la ruta absoluta del recurso, compatible con PyInstaller"""
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# -------------------- Contexto --------------------
dpg.create_context()
# -------------------- Pantalla de Presentación (Splash) --------------------

# Cargar imagen
image_path = resource_path("assets/imagen.png")
width, height, channels, data = dpg.load_image(image_path)
with dpg.texture_registry():
    dpg.add_static_texture(width, height, data, tag="splash_image")


# Tema para el splash
with dpg.theme() as splash_theme:
    with dpg.theme_component(dpg.mvAll):
        dpg.add_theme_color(dpg.mvThemeCol_WindowBg, (30, 30, 48), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_Text,     (255, 255, 255), category=dpg.mvThemeCat_Core)

# Ventana splash
with dpg.window(label="",
                tag="splash_screen",
                no_title_bar=True,
                no_resize=True,
                no_move=True,
                no_collapse=True,
                width=700,
                height=700,
                pos=[0, 0]):

    with dpg.group(tag="splash_group", horizontal=False):
        dpg.add_image("splash_image", width=128, height=128)
        dpg.add_spacer(height=30)
        dpg.add_text("Cruz Granados Luis Axel")
        dpg.add_text("Roman Zarza Samuel Ivan")
        dpg.add_spacer(height=10)
        dpg.add_text("BoxyCorp", color=(255, 255, 255))

# Crear viewport
dpg.create_viewport(title='Cargando...', width=700, height=700, resizable=False, decorated=False)

# Centrar ventana del splash y centrar contenido
user32 = ctypes.windll.user32
user32.SetProcessDPIAware()
display_width  = user32.GetSystemMetrics(0)
display_height = user32.GetSystemMetrics(1)
center_x = (display_width  - 700) // 2
center_y = (display_height - 700) // 2
dpg.set_viewport_pos([center_x, center_y])

# Centrar contenido dentro del splash dinámicamente
def center_splash_group():
    splash_width = 700
    group_width = 128  # Ancho de la imagen (lo más ancho del grupo)
    x = (splash_width - group_width) // 2
    dpg.set_item_pos("splash_group", [x, 150])  # 150: vertical para bajarlo un poco

dpg.setup_dearpygui()
dpg.show_viewport()
dpg.bind_theme(splash_theme)
center_splash_group()

# Mostrar splash
start = time.time()
while time.time() - start < 4:
    dpg.render_dearpygui_frame()

# Eliminar splash
dpg.delete_item("splash_screen")


# -------------------- Aplicación Principal --------------------

# Variables globales
vector_data         = []
is_dragging         = False
drag_start_pos      = [0, 0]
viewport_start_pos  = [0, 0]
target_viewport_pos = [0, 0]

# Tema personalizado para Inputs
with dpg.theme() as input_theme:
    with dpg.theme_component(dpg.mvInputFloat):
        dpg.add_theme_color(dpg.mvThemeCol_FrameBg,      (40, 40, 60), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_Button,       (255,165,0), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_ButtonHovered,(255,200,100), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_ButtonActive, (255,140,0), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_Text,         (255,255,255), category=dpg.mvThemeCat_Core)
    with dpg.theme_component(dpg.mvButton):
        dpg.add_theme_color(dpg.mvThemeCol_Text, (0, 0, 0), category=dpg.mvThemeCat_Core)

# Funciones de la app
def add_vector_callback():
    with dpg.group(horizontal=True, parent="vectors_group") as gid:
        mag = dpg.add_input_float(label="Magnitud", width=120, min_value=0, format="%.2f")
        dpg.bind_item_theme(mag, input_theme)
        ang = dpg.add_input_float(label="Ángulo (°)", width=120, format="%.2f")
        dpg.bind_item_theme(ang, input_theme)
        dpg.add_button(label="X", width=25, height=25, callback=lambda: remove_vector(gid))
        vector_data.append((gid, mag, ang))

def remove_vector(gid):
    for i, (grp, _, _) in enumerate(vector_data):
        if grp == gid:
            dpg.delete_item(grp)
            vector_data.pop(i)
            break

def calculate_vectors_callback():
    sum_x = sum_y = 0
    dpg.delete_item("results_group", children_only=True)
    for idx, (_, mid, aid) in enumerate(vector_data):
        m = dpg.get_value(mid)
        a = math.radians(dpg.get_value(aid))
        x = m * math.cos(a)
        y = m * math.sin(a)
        sum_x += x; sum_y += y
        dpg.add_text(f"Vector {idx+1}:", color=(173,216,230), parent="results_group")
        dpg.add_text(f"  X = {x:.2f}", parent="results_group")
        dpg.add_text(f"  Y = {y:.2f}", parent="results_group")
        dpg.add_spacer(height=5, parent="results_group")
    resultant = math.hypot(sum_x, sum_y)
    direction = math.degrees(math.atan2(sum_y, sum_x))
    dpg.add_spacer(height=10, parent="results_group")
    dpg.add_text("Suma de componentes:", color=(144,238,144), parent="results_group")
    dpg.add_text(f"  X_total = {sum_x:.2f}", parent="results_group")
    dpg.add_text(f"  Y_total = {sum_y:.2f}", parent="results_group")
    dpg.add_spacer(height=10, parent="results_group")
    dpg.add_text("Vector Resultante:", color=(144,238,144), parent="results_group")
    dpg.add_text(f"  Magnitud = {resultant:.2f}", parent="results_group")
    dpg.add_text(f"  Ángulo   = {direction:.2f}°", parent="results_group")

def close_program_callback():
    dpg.stop_dearpygui()

def mouse_drag_check():
    global is_dragging, drag_start_pos, viewport_start_pos, target_viewport_pos
    if dpg.is_mouse_button_down(0):
        if not is_dragging and dpg.is_item_hovered("drag_zone"):
            is_dragging = True
            drag_start_pos      = dpg.get_mouse_pos()
            viewport_start_pos  = dpg.get_viewport_pos()
        if is_dragging:
            mx, my = dpg.get_mouse_pos()
            dx = mx - drag_start_pos[0]
            dy = my - drag_start_pos[1]
            target_viewport_pos = [viewport_start_pos[0] + dx, viewport_start_pos[1] + dy]
    else:
        is_dragging = False

def smooth_move():
    cx, cy = dpg.get_viewport_pos()
    sx = cx + (target_viewport_pos[0] - cx) * 0.2
    sy = cy + (target_viewport_pos[1] - cy) * 0.2
    dpg.set_viewport_pos((int(sx), int(sy)))

# Tema oscuro principal
with dpg.theme() as dark_theme:
    with dpg.theme_component(dpg.mvAll):
        dpg.add_theme_color(dpg.mvThemeCol_WindowBg,      (30,30,48), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_ChildBg,       (40,40,60), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_Button,        (255,165,0), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_ButtonHovered, (255,200,100), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_ButtonActive,  (255,140,0), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_TitleBgActive, (40,40,60), category=dpg.mvThemeCat_Core)
        dpg.add_theme_color(dpg.mvThemeCol_Text,          (220,220,220), category=dpg.mvThemeCat_Core)

# Tema para botones (texto negro)
with dpg.theme() as button_theme:
    with dpg.theme_component(dpg.mvButton):
        dpg.add_theme_color(dpg.mvThemeCol_Text, (0, 0, 0), category=dpg.mvThemeCat_Core)

# Función para centrar la ventana principal dentro del viewport
def reposition_main_window():
    dw = dpg.get_viewport_width()
    dh = dpg.get_viewport_height()
    w, h = 700, 700
    dpg.set_item_pos("main_window", [(dw - w)//2, (dh - h)//2])
    dpg.set_item_width("main_window", w)
    dpg.set_item_height("main_window", h)

# Ventana principal (sin decoración), ocupará su propio espacio centrado
with dpg.window(label="",
                tag="main_window",
                no_title_bar=True,
                no_resize=True,
                no_collapse=True,
                no_move=True,
                width=700,
                height=700,
                pos=[0, 0]):
    with dpg.group(horizontal=True, tag="drag_zone"):
        dpg.add_spacer(width=640)
        dpg.add_button(label="X", width=30, height=30, callback=close_program_callback)
    dpg.add_text("Calculadora de Vectores", color=(255,255,255), bullet=True)
    dpg.add_separator()
    with dpg.group(horizontal=True):
        dpg.add_button(label="Agregar Vector", callback=add_vector_callback, width=150)
        dpg.add_button(label="Calcular", callback=calculate_vectors_callback, width=150)
    dpg.add_spacer(height=10)
    dpg.add_text("Datos de los Vectores:", color=(135,206,250))
    with dpg.child_window(width=-1, height=150, border=True):
        dpg.add_group(horizontal=False, tag="vectors_group")
    dpg.add_spacer(height=10)
    dpg.add_text("Resultados:", color=(135,206,250))
    with dpg.child_window(width=-1, height=300, border=True):
        dpg.add_group(horizontal=False, tag="results_group")
    with dpg.group(horizontal=True):
        dpg.add_spacer(width=510)
        dpg.add_text("Versión 1.6 | © BoxyCorp", color=(255,255,255))

# Handler para arrastrar ventana
with dpg.handler_registry():
    dpg.add_mouse_move_handler(callback=lambda s,a: mouse_drag_check())

# Aplicar temas y centrar ventana principal
dpg.bind_theme(dark_theme)
dpg.bind_item_theme("main_window", button_theme)
reposition_main_window()

# Bucle principal
while dpg.is_dearpygui_running():
    smooth_move()
    dpg.render_dearpygui_frame()

# Limpieza
dpg.destroy_context()
